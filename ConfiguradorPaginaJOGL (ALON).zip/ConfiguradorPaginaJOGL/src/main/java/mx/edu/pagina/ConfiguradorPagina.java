package mx.edu.pagina;

import java.awt.*;
import javax.swing.*;

/** Interfaz distribuida como el ejemplo de la actividad. */
public final class ConfiguradorPagina extends JFrame {
    private static final long serialVersionUID = 1L;
    private final JSpinner inferior = margen(10);
    private final JSpinner superior = margen(5);
    private final JComboBox<String> orientacion = new JComboBox<>(new String[]{"Vertical", "Horizontal"});
    private final VistaPagina hoja = new VistaPagina(true);
    private final VistaPagina vistaOrientacion = new VistaPagina(false);
    private Configuracion configuracion = new Configuracion(true, 5, 10, 0, 0);
    private boolean sincronizando;

    public ConfiguradorPagina() {
        super("");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel contenido = new JPanel(null);
        contenido.setBackground(new Color(240, 240, 240));
        contenido.setPreferredSize(new Dimension(484, 384));
        setContentPane(contenido);

        etiqueta(contenido, "Hoja", 39, 20, 70, 16);
        hoja.setBounds(17, 38, 94, 126);
        contenido.add(hoja);

        etiqueta(contenido, "Margen inferior", 140, 20, 112, 16);
        inferior.setBounds(141, 42, 49, 25);
        contenido.add(inferior);
        etiqueta(contenido, "Margen superior", 140, 108, 112, 16);
        superior.setBounds(141, 130, 49, 25);
        contenido.add(superior);

        etiqueta(contenido, "Orientación de página.", 279, 20, 190, 16);
        orientacion.setBounds(279, 46, 172, 20);
        orientacion.setSelectedIndex(1);
        contenido.add(orientacion);
        vistaOrientacion.setBounds(270, 74, 180, 91);
        contenido.add(vistaOrientacion);

        JButton inicializar = new JButton("Inicializar");
        inicializar.setBounds(39, 213, 145, 22);
        contenido.add(inicializar);
        inferior.addChangeListener(e -> aplicar());
        superior.addChangeListener(e -> aplicar());
        orientacion.addActionListener(e -> aplicar());
        inicializar.addActionListener(e -> {
            configuracion = Configuracion.inicial();
            sincronizar();
            actualizarVistas();
        });
        actualizarVistas();
        setResizable(false);
        pack();
        setLocationRelativeTo(null);
    }
    private void aplicar() {
        if (sincronizando) return;
        try {
            configuracion = new Configuracion(orientacion.getSelectedIndex() == 1,
                ((Number) superior.getValue()).intValue(),
                ((Number) inferior.getValue()).intValue(), 0, 0);
            actualizarVistas();
        } catch (IllegalArgumentException ex) {
            sincronizar();
            JOptionPane.showMessageDialog(this,
                "Los márgenes deben dejar espacio dentro de la página.",
                "Revisa los márgenes", JOptionPane.WARNING_MESSAGE);
        }
    }
    private void sincronizar() {
        sincronizando = true;
        try {
            superior.setValue(configuracion.superior());
            inferior.setValue(configuracion.inferior());
            orientacion.setSelectedIndex(configuracion.horizontal() ? 1 : 0);
        } finally { sincronizando = false; }
    }
    private void actualizarVistas() {
        hoja.actualizar(configuracion);
        vistaOrientacion.setSize(180, configuracion.horizontal() ? 91 : 180);
        vistaOrientacion.actualizar(configuracion);
    }
    private static JSpinner margen(int valor) {
        JSpinner spinner = new JSpinner(new SpinnerNumberModel(valor, 0, 296, 1));
        JSpinner.NumberEditor editor = new JSpinner.NumberEditor(spinner, "0");
        spinner.setEditor(editor);
        editor.getTextField().setFocusLostBehavior(JFormattedTextField.COMMIT_OR_REVERT);
        return spinner;
    }
    private static void etiqueta(JPanel p, String texto, int x, int y, int w, int h) {
        JLabel label = new JLabel(texto);
        label.setBounds(x, y, w, h);
        p.add(label);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
                Font fuente = new Font("Dialog", Font.PLAIN, 11);
                for (String clave : new String[]{"Label.font", "Button.font", "ComboBox.font", "Spinner.font", "FormattedTextField.font"})
                    UIManager.put(clave, fuente);
                new ConfiguradorPagina().setVisible(true);
            } catch (Throwable ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "No se pudo iniciar JOGL: " + ex.getMessage(),
                    "Error al iniciar", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}
