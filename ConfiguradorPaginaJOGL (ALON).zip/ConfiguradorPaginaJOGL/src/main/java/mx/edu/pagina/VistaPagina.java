package mx.edu.pagina;

import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.GLJPanel;

/** Dos vistas JOGL: hoja con márgenes y rectángulo de orientación. */
public final class VistaPagina extends GLJPanel implements GLEventListener {
    private static final long serialVersionUID = 1L;
    private final boolean mostrarMargenes;
    private volatile Configuracion configuracion = Configuracion.inicial();

    public VistaPagina(boolean mostrarMargenes) {
        super(new GLCapabilities(GLProfile.get(GLProfile.GL2)));
        this.mostrarMargenes = mostrarMargenes;
        addGLEventListener(this);
    }
    public void actualizar(Configuracion nueva) {
        configuracion = nueva;
        repaint();
    }
    @Override public void init(GLAutoDrawable d) {
        d.getGL().glDisable(GL.GL_DEPTH_TEST);
    }
    @Override public void dispose(GLAutoDrawable d) { }
    @Override public void reshape(GLAutoDrawable d, int x, int y, int w, int h) { }
    @Override public void display(GLAutoDrawable d) {
        GL2 gl = d.getGL().getGL2();
        int w = Math.max(1, d.getSurfaceWidth()), h = Math.max(1, d.getSurfaceHeight());
        gl.glViewport(0, 0, w, h);
        gl.glClearColor(240f / 255f, 240f / 255f, 240f / 255f, 1);
        gl.glClear(GL.GL_COLOR_BUFFER_BIT);
        gl.glMatrixMode(GL2.GL_PROJECTION);
        gl.glLoadIdentity();
        gl.glOrtho(0, w, h, 0, -1, 1);
        gl.glMatrixMode(GL2.GL_MODELVIEW);
        gl.glLoadIdentity();
        Configuracion c = configuracion;
        double sx = w / (double) Math.max(1, getWidth());
        double sy = h / (double) Math.max(1, getHeight());
        gl.glLineWidth((float) Math.max(1, sx));
        if (mostrarMargenes) {
            // La hoja izquierda permanece vertical como en la referencia.
            double x = 3 * sx, y = 2 * sy, ancho = w - 7 * sx, alto = h - 5 * sy;
            borde(gl, x, y, ancho, alto, 0f, 0f, .7f);
            // Los márgenes se miden respecto a la altura de la página seleccionada.
            gl.glColor3f(.9f, .30f, .33f);
            gl.glBegin(GL2.GL_LINES);
            double arriba = y + alto * c.superior() / c.alto();
            double abajo = y + alto * (1 - c.inferior() / (double) c.alto());
            gl.glVertex2d(x, arriba); gl.glVertex2d(x + ancho, arriba);
            gl.glVertex2d(x, abajo); gl.glVertex2d(x + ancho, abajo);
            gl.glEnd();
        } else {
            // Misma proporción aproximada 2:1 del rectángulo del ejemplo.
            double ancho = c.horizontal() ? 174 * sx : 86 * sx;
            double alto = c.horizontal() ? 86 * sy : 174 * sy;
            // El panel cambia de altura para alojar la vista vertical completa.
            borde(gl, 2 * sx, 2 * sy, ancho, alto, .90f, .36f, .47f);
        }
        gl.glFlush();
    }
    private static void borde(GL2 gl, double x, double y, double ancho, double alto, float r, float g, float b) {
        gl.glColor3f(r, g, b);
        gl.glBegin(GL2.GL_LINE_LOOP);
        gl.glVertex2d(x, y); gl.glVertex2d(x + ancho, y);
        gl.glVertex2d(x + ancho, y + alto); gl.glVertex2d(x, y + alto);
        gl.glEnd();
    }
}
